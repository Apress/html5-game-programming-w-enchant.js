enchant();
var game;

window.onload = function(){
    game = new Core(320, 320);
    game.fps = 60;
    game.onload = function(){
		scene = new Scene3D();
		scene.setDirectionalLight(new DirectionalLight());

		camera = new Camera3D();
		camera.y = 1.1;
		camera.z = -1.65;
		camera.centerZ = -10;
		camera.upVectorZ = 10;
		camera.upVectorY = 100;
		scene.setCamera(camera);

		scene.addChild(new Droid(-1.1, -1.5, -9.2));

	};

	game.start();
};
